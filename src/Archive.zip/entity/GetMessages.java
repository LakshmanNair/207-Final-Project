package entity;

public interface GetMessages {
    // use MessageHistory and rewrite privatechat to go through this interface
}
