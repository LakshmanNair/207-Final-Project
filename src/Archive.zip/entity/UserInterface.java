package entity;

public interface UserInterface {
    String getUserID();

    String getUsername();

    String getPassword();
}
