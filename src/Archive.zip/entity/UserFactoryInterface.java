package entity;

public interface UserFactoryInterface {
    static User createUser(String username, String password) {
        return null;
    }
}
