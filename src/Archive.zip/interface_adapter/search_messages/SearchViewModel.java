package interface_adapter.search_messages;

public class SearchViewModel {
    // TODO: Attributes to represent search results
}
