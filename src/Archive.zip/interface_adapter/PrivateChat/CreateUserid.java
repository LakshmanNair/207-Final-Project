package interface_adapter.PrivateChat;

import java.util.ArrayList;

public class CreateUserid {
    private ArrayList<Integer> user_ids;

    public static Integer NewUserID() {
        return 1;
    }
}
