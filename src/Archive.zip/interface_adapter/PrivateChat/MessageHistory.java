package interface_adapter.PrivateChat;

public class MessageHistory {
}
