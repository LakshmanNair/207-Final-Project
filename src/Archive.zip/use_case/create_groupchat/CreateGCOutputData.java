package use_case.create_groupchat;

public class CreateGCOutputData {
}
