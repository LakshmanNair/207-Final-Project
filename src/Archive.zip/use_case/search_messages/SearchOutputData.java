package use_case.search_messages;

public class SearchOutputData {
}
