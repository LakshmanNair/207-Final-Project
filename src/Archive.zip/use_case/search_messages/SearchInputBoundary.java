package use_case.search_messages;

public interface SearchInputBoundary {
    void searchMessages(SearchInputData searchInputData);
}
