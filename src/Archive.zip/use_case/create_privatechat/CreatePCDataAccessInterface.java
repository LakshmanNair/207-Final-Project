package use_case.create_privatechat;

public interface CreatePCDataAccessInterface {
}
