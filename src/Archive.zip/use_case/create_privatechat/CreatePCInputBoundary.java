package use_case.create_privatechat;

public interface CreatePCInputBoundary {
    void execute(CreatePCInputData createPCInputData);
}
