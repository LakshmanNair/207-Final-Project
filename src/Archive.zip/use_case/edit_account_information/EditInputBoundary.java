package use_case.edit_account_information;

public interface EditInputBoundary {
    void execute(EditInputData editInputData);
}
