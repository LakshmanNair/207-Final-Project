package use_case.groupChat;

public interface GroupChatUserDataAccessInterface {
}
