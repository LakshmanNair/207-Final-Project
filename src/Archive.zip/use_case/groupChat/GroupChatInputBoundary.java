package use_case.groupChat;

public interface GroupChatInputBoundary {
    void sendMessage(GroupChatInputData groupChatInputData);
}
