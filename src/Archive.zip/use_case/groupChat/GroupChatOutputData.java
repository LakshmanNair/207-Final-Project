package use_case.groupChat;

public class GroupChatOutputData {
}
