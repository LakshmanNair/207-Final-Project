package use_case.create_account;

public interface CreateAccountInputBoundary {
    void execute(CreateAccountInputData createAccountInputData);
}
