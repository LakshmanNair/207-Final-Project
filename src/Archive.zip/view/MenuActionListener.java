package view;

public interface MenuActionListener {
    void onPrivateChatClicked();
}
