package view;

public class MainScreenView {
}
